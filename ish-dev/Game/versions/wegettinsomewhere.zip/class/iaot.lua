class:append({
    domain = 'opentycoon',
    type = 'commands',
    hello = function()
        print('hello world!')
      end
  })
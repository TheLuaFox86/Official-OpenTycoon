print('opentycoon prealpha')
go = true
while go do
  io.write('$0> ')
  local a = io.read()
  if a == 'exit' then go = false return end
  print(pcall(class.opentycoon.commands[a]))
end
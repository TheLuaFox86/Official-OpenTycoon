_G.class =  {}
function class:append(tb)
  if not self[tb.domain] then self[tb.domain] = {} end
  self[tb.domain][tb.type] = tb
end
for a in platform.fs.listdir(config.tmpp .. config.di .. "class") do
  dofile(config.tmpp .. config.di .. "class" .. config.di .. a)
end
wget https://raw.githubusercontent.com/TheLuaFox86/Official-OpenTycoon/main/VI-linux.lua && lua5.3 VI-linux.lua $HOME/OpenTycoon/Game
$WD= $PWD
cd $HOME/OpenTycoon
lua5.3 launcher.lua
cd $WD

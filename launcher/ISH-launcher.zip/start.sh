$WD= $PWD
cd $HOME/OpenTycoon
lua5.3 launcher.lua
cd $WD

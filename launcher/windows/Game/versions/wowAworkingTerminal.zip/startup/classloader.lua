_G.class =  {}
function class:append(tb)
  if not self[tb.domain] then self[tb.domain] = {} end
  self[tb.domain][tb.type] = tb
end
function class:getById(t, id)
  local a = {}
  for i, v in ipairs(id:split(":")) do
    a[i]=v
  end
  return self[a[1]][t][a[2]]
end
function class:setById(t, id, val)
  local a = {}
  for i, v in ipairs(id:split(":")) do
    a[i]=v
  end
  self[a[1]][t][a[2]] = val
 end

dofile(config.tmpp .. config.di .. 'class' .. config.di .. 'MainClass.lua')

pcall(function()
    pluginp = config.pluginp
    dofile(pluginp .. config.di .. 'init4mods.lua')
end)
for a in platform.fs.listdir(config.tmpp .. config.di .. "class") do
  if a ~= "MainClass.lua" then
    dofile(config.tmpp .. config.di .. "class" .. config.di .. a)
  end
end
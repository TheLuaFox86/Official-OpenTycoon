class.opentycoon.item:item({
    id='paper',
    price=250,
    profit=1.87,
    amount=0,
    DESC="IMA\nTEST"
})
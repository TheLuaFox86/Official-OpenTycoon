while true do
  print('yay')
end